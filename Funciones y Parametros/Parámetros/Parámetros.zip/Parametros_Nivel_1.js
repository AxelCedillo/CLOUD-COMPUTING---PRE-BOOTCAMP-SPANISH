function greet(name){
    console.log("¡Buen día, " + name)
}

var nombre = "Axel Cedillo Olea";

greet(nombre)