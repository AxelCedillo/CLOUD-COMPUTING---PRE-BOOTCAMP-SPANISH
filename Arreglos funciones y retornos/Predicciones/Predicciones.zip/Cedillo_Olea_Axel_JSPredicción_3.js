function add(num1, num2){ // num1 = 10 , num2 = 20
        console.log("¡Sumando números!");
        console.log("num1 es: " + num1);
        console.log("num2 es: " + num2);
        var sum = num1 + num2;
        console.log(sum);
    }

/*consola*/
//¡Sumando números!
//num1 es: 10
//num2 es: 20
//30