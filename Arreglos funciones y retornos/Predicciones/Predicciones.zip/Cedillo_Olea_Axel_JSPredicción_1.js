function myBirthYearFunc(){
        console.log("Nací en" + 1980);
    }

/*consola*/
//Naci en1980