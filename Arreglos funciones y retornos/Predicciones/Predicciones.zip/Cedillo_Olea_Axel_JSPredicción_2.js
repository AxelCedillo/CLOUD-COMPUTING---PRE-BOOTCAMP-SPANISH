function myBirthYearFunc(birthYearInput){ // birthYearInput = 1980
        console.log("Nací en" + birthYearInput);
    }  

/*consola*/
//Naci en1980